export type Blockchain = 'ethereum' | 'polygon' | 'solana' | 'base';
export type UserRole = 'creator' | 'collector' | 'admin';
export type ListingStatus = 'active' | 'sold' | 'cancelled';
export type ListingType = 'fixed' | 'auction';

export interface User {
  uid: string;
  walletAddress?: string;
  displayName: string;
  bio?: string;
  photoURL?: string;
  role: UserRole;
  createdAt: any;
}

export interface Asset {
  id: string;
  creatorId: string;
  title: string;
  description?: string;
  fileURL: string;
  previewURL?: string;
  mimeType?: string;
  ipfsHash?: string;
  createdAt: any;
}

export interface Token {
  id: string;
  assetId: string;
  creatorId: string;
  ownerId: string;
  tokenId?: string;
  contractAddress?: string;
  blockchain: Blockchain;
  royaltyBps: number;
  metadata?: any;
  mintedAt: any;
}

export interface Listing {
  id: string;
  tokenId: string;
  sellerId: string;
  price: number;
  currency: string;
  status: ListingStatus;
  type: ListingType;
  createdAt: any;
}

export interface Transaction {
  id: string;
  listingId: string;
  tokenId: string;
  buyerId: string;
  sellerId: string;
  amount: number;
  currency: string;
  platformFee: number;
  creatorRoyalty: number;
  timestamp: any;
}
