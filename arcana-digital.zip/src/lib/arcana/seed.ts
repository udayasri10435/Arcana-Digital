import { 
  collection, 
  getDocs, 
  addDoc, 
  Timestamp,
  query,
  limit
} from 'firebase/firestore';
import { db } from '../../firebase';

export const seedInitialData = async () => {
  try {
    const listingsSnap = await getDocs(query(collection(db, 'listings'), limit(1)));
    if (listingsSnap.empty) {
      console.log('Seeding initial data...');
      
      // Create some mock listings
      const mockListings = [
        {
          tokenId: 'token-1',
          sellerId: 'mock-seller-1',
          price: 0.5,
          currency: 'ETH',
          status: 'active',
          type: 'fixed',
          createdAt: Timestamp.now()
        },
        {
          tokenId: 'token-2',
          sellerId: 'mock-seller-2',
          price: 1.2,
          currency: 'ETH',
          status: 'active',
          type: 'auction',
          createdAt: Timestamp.now()
        },
        {
          tokenId: 'token-3',
          sellerId: 'mock-seller-3',
          price: 0.05,
          currency: 'ETH',
          status: 'active',
          type: 'fixed',
          createdAt: Timestamp.now()
        },
        {
          tokenId: 'token-4',
          sellerId: 'mock-seller-4',
          price: 2.5,
          currency: 'ETH',
          status: 'active',
          type: 'auction',
          createdAt: Timestamp.now()
        }
      ];

      for (const listing of mockListings) {
        await addDoc(collection(db, 'listings'), listing);
      }
      console.log('Seeding complete.');
    }
  } catch (error) {
    console.error('Error seeding data:', error);
  }
};
