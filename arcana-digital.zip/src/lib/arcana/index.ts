import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot,
  Timestamp,
  getDocFromServer
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import { db, auth } from '../../firebase';
import { User, Asset, Token, Listing, Transaction } from '../../types';

// Error Handler
const handleFirestoreError = (error: any, operation: string, path: string | null) => {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType: operation,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
};

// 1. Wallet & Identity Service
export const IdentityService = {
  async login() {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      // Check if user profile exists
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (!userDoc.exists()) {
        const newUser: User = {
          uid: user.uid,
          displayName: user.displayName || 'Anonymous',
          photoURL: user.photoURL || '',
          role: 'collector',
          createdAt: Timestamp.now()
        };
        await setDoc(doc(db, 'users', user.uid), newUser);
      }
      return user;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },
  
  async logout() {
    await signOut(auth);
  },
  
  onAuthChange(callback: (user: any) => void) {
    return onAuthStateChanged(auth, callback);
  },

  async getUserProfile(uid: string) {
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      return userDoc.exists() ? (userDoc.data() as User) : null;
    } catch (error) {
      handleFirestoreError(error, 'get', `users/${uid}`);
    }
  }
};

// 2. Creator Studio Service
export const CreatorService = {
  async updateProfile(uid: string, data: Partial<User>) {
    try {
      await updateDoc(doc(db, 'users', uid), data);
    } catch (error) {
      handleFirestoreError(error, 'update', `users/${uid}`);
    }
  },
  
  async getCreators() {
    try {
      const q = query(collection(db, 'users'), where('role', '==', 'creator'), limit(10));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => doc.data() as User);
    } catch (error) {
      handleFirestoreError(error, 'list', 'users');
    }
  }
};

// 3. Digital Asset Service
export const AssetService = {
  async uploadAsset(asset: Omit<Asset, 'id' | 'createdAt'>) {
    try {
      const docRef = await addDoc(collection(db, 'assets'), {
        ...asset,
        createdAt: Timestamp.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, 'create', 'assets');
    }
  },
  
  async getAsset(id: string) {
    try {
      const docSnap = await getDoc(doc(db, 'assets', id));
      return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } as Asset : null;
    } catch (error) {
      handleFirestoreError(error, 'get', `assets/${id}`);
    }
  }
};

// 4. Token & NFT Service
export const TokenService = {
  async mintToken(token: Omit<Token, 'id' | 'mintedAt'>) {
    try {
      const docRef = await addDoc(collection(db, 'tokens'), {
        ...token,
        mintedAt: Timestamp.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, 'create', 'tokens');
    }
  },
  
  async getTokensByOwner(ownerId: string) {
    try {
      const q = query(collection(db, 'tokens'), where('ownerId', '==', ownerId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Token));
    } catch (error) {
      handleFirestoreError(error, 'list', 'tokens');
    }
  }
};

// 5. Marketplace Service
export const MarketplaceService = {
  async createListing(listing: Omit<Listing, 'id' | 'createdAt'>) {
    try {
      const docRef = await addDoc(collection(db, 'listings'), {
        ...listing,
        createdAt: Timestamp.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, 'create', 'listings');
    }
  },
  
  async getActiveListings() {
    try {
      const q = query(collection(db, 'listings'), where('status', '==', 'active'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Listing));
    } catch (error) {
      handleFirestoreError(error, 'list', 'listings');
    }
  }
};

// 6. Royalty & Split Service
export const RoyaltyService = {
  async calculatePayout(amount: number, royaltyBps: number) {
    const platformFee = amount * 0.025; // 2.5%
    const creatorRoyalty = amount * (royaltyBps / 10000);
    const sellerNet = amount - platformFee - creatorRoyalty;
    return { platformFee, creatorRoyalty, sellerNet };
  }
};

// 7. Licensing & Access Service
export const LicensingService = {
  async verifyAccess(tokenId: string, userId: string) {
    try {
      const tokenDoc = await getDoc(doc(db, 'tokens', tokenId));
      if (!tokenDoc.exists()) return false;
      const token = tokenDoc.data() as Token;
      return token.ownerId === userId || token.creatorId === userId;
    } catch (error) {
      handleFirestoreError(error, 'get', `tokens/${tokenId}`);
    }
  }
};

// 8. Community & Engagement Service
export const CommunityService = {
  // Simulated engagement
  async getCollectorLeaderboard() {
    return [
      { name: 'Alice', points: 1200 },
      { name: 'Bob', points: 950 },
      { name: 'Charlie', points: 800 }
    ];
  }
};

// 9. Checkout & Payment Service
export const PaymentService = {
  async processPurchase(listingId: string, buyerId: string) {
    try {
      const listingDoc = await getDoc(doc(db, 'listings', listingId));
      if (!listingDoc.exists()) throw new Error('Listing not found');
      const listing = listingDoc.data() as Listing;
      
      const tokenDoc = await getDoc(doc(db, 'tokens', listing.tokenId));
      if (!tokenDoc.exists()) throw new Error('Token not found');
      const token = tokenDoc.data() as Token;
      
      const { platformFee, creatorRoyalty } = await RoyaltyService.calculatePayout(listing.price, token.royaltyBps);
      
      // Update listing status
      await updateDoc(doc(db, 'listings', listingId), { status: 'sold' });
      
      // Update token owner
      await updateDoc(doc(db, 'tokens', listing.tokenId), { ownerId: buyerId });
      
      // Create transaction record
      const transaction: Omit<Transaction, 'id'> = {
        listingId,
        tokenId: listing.tokenId,
        buyerId,
        sellerId: listing.sellerId,
        amount: listing.price,
        currency: listing.currency,
        platformFee,
        creatorRoyalty,
        timestamp: Timestamp.now()
      };
      await addDoc(collection(db, 'transactions'), transaction);
      
      return true;
    } catch (error) {
      handleFirestoreError(error, 'write', 'checkout');
    }
  }
};

// 10. Analytics & Discovery Service
export const AnalyticsService = {
  async getMarketStats() {
    return {
      volume24h: 125.5,
      floorPrice: 0.05,
      totalCreators: 450
    };
  }
};

// Connection Test
export const testConnection = async () => {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    }
  }
};
