import { GoogleGenAI, Modality, Type, ThinkingLevel } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const GeminiService = {
  // 1. Chatbot (General/Complex)
  async chat(message: string, history: any[] = [], isComplex = false) {
    const model = isComplex ? "gemini-3.1-pro-preview" : "gemini-3-flash-preview";
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction: "You are the Arcana Digital Protocol Assistant. You help users navigate the digital goods marketplace, understand NFT technology, and provide creator advice. Use a technical, professional, yet approachable tone.",
      },
    });

    // Note: sendMessage only accepts message string, history is handled by the chat instance if created with it
    // But for simplicity in this demo we just send the message
    const response = await chat.sendMessage({ message });
    return response.text;
  },

  // 2. Image Generation (High Quality)
  async generateImage(prompt: string, size: "1K" | "2K" | "4K" = "1K") {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-image-preview",
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size,
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // 3. Search Grounding
  async searchMarketInfo(query: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  },

  // 4. Low Latency / Fast Tasks
  async fastResponse(prompt: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: prompt,
    });
    return response.text;
  },

  // 5. Audio Transcription
  async transcribeAudio(base64Audio: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { text: "Transcribe this audio accurately." },
          { inlineData: { mimeType: "audio/wav", data: base64Audio } }
        ]
      }
    });
    return response.text;
  }
};

// Live API Helper (Conceptual for the UI to use)
export const connectLiveAssistant = (callbacks: any) => {
  return ai.live.connect({
    model: "gemini-3.1-flash-live-preview",
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
      },
      systemInstruction: "You are the Arcana Live Voice Assistant. Help users with real-time queries about the protocol.",
    },
  });
};
