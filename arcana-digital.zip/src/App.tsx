import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase';
import { IdentityService, testConnection } from './lib/arcana';
import { seedInitialData } from './lib/arcana/seed';
import Layout from './components/Layout';
import Marketplace from './pages/Marketplace';
import CreatorStudio from './pages/CreatorStudio';

// Mock pages for demo
const Collection = () => (
  <div className="space-y-8">
    <h1 className="text-4xl font-mono font-bold tracking-tighter uppercase italic">MY COLLECTION</h1>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {[1, 2, 3].map(i => (
        <div key={i} className="aspect-square bg-white border border-[#141414] rounded-sm flex items-center justify-center">
          <p className="font-mono text-[10px] uppercase tracking-widest text-[#141414]/40">Asset #{i} in Wallet</p>
        </div>
      ))}
    </div>
  </div>
);

const Analytics = () => (
  <div className="space-y-8">
    <h1 className="text-4xl font-mono font-bold tracking-tighter uppercase italic">PROTOCOL ANALYTICS</h1>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="h-64 bg-white border border-[#141414] rounded-sm p-6">
        <p className="font-mono text-[10px] uppercase tracking-widest text-[#141414]/40 mb-4">Volume Over Time</p>
        <div className="h-full flex items-end gap-2">
          {[40, 70, 45, 90, 65, 80, 55].map((h, i) => (
            <div key={i} className="flex-1 bg-[#141414]" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
      <div className="h-64 bg-white border border-[#141414] rounded-sm p-6">
        <p className="font-mono text-[10px] uppercase tracking-widest text-[#141414]/40 mb-4">Creator Distribution</p>
        <div className="w-40 h-40 rounded-full border-8 border-[#141414] mx-auto flex items-center justify-center">
          <span className="font-mono text-xs font-bold">450+</span>
        </div>
      </div>
    </div>
  </div>
);

const Community = () => (
  <div className="space-y-8">
    <h1 className="text-4xl font-mono font-bold tracking-tighter uppercase italic">COMMUNITY HUB</h1>
    <div className="space-y-4">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="p-6 bg-white border border-[#141414] rounded-sm flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-[#141414]/5 rounded-full" />
            <div>
              <p className="font-mono text-xs font-bold uppercase tracking-widest">Creator_Announce_{i}</p>
              <p className="font-mono text-[10px] text-[#141414]/60">Just dropped a new collection on Polygon!</p>
            </div>
          </div>
          <button className="text-[10px] font-mono uppercase tracking-widest text-blue-600 hover:underline">View Drop</button>
        </div>
      ))}
    </div>
  </div>
);

const Governance = () => (
  <div className="space-y-8">
    <h1 className="text-4xl font-mono font-bold tracking-tighter uppercase italic">GOVERNANCE</h1>
    <div className="p-12 bg-[#141414] text-[#E4E3E0] rounded-sm space-y-6">
      <h2 className="text-2xl font-mono font-bold uppercase tracking-tighter">Active Proposal: AIP-042</h2>
      <p className="font-mono text-xs text-[#E4E3E0]/60 max-w-xl">
        Should the protocol implement a 1% reduction in marketplace fees for Genesis NFT holders?
      </p>
      <div className="flex gap-4">
        <button className="bg-[#E4E3E0] text-[#141414] px-8 py-3 font-mono text-[10px] uppercase tracking-widest font-bold hover:bg-white transition-colors">Vote For</button>
        <button className="border border-[#E4E3E0]/20 px-8 py-3 font-mono text-[10px] uppercase tracking-widest font-bold hover:bg-[#E4E3E0]/10 transition-colors">Vote Against</button>
      </div>
    </div>
  </div>
);

import { AIAssistant } from './components/AIAssistant';
import { KeyGuard } from './components/KeyGuard';

export default function App() {
  const [user, setUser] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    testConnection();
    const unsubscribe = IdentityService.onAuthChange((u) => {
      setUser(u);
      if (u && u.email === 'udayatube2020@gmail.com') {
        seedInitialData();
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#E4E3E0] flex items-center justify-center">
        <div className="space-y-4 text-center">
          <div className="w-12 h-12 border-4 border-[#141414] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="font-mono text-[10px] uppercase tracking-widest text-[#141414]/40">Initializing Arcana Protocol...</p>
        </div>
      </div>
    );
  }

  return (
    <KeyGuard>
      <Router>
        <Layout user={user}>
          <Routes>
            <Route path="/" element={<Marketplace />} />
            <Route path="/studio" element={<CreatorStudio />} />
            <Route path="/collection" element={<Collection />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/governance" element={<Governance />} />
            <Route path="/community" element={<Community />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
        <AIAssistant />
      </Router>
    </KeyGuard>
  );
}
