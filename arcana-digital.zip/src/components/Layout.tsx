import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutGrid, 
  Palette, 
  Wallet, 
  TrendingUp, 
  ShieldCheck, 
  Users, 
  Settings, 
  LogOut,
  Menu,
  X,
  Search,
  Bell
} from 'lucide-react';
import { cn } from '../lib/utils';
import { IdentityService } from '../lib/arcana';

interface LayoutProps {
  children: React.ReactNode;
  user: any;
}

export default function Layout({ children, user }: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);
  const location = useLocation();

  const navItems = [
    { name: 'Marketplace', icon: LayoutGrid, path: '/' },
    { name: 'Creator Studio', icon: Palette, path: '/studio' },
    { name: 'My Collection', icon: Wallet, path: '/collection' },
    { name: 'Analytics', icon: TrendingUp, path: '/analytics' },
    { name: 'Governance', icon: ShieldCheck, path: '/governance' },
    { name: 'Community', icon: Users, path: '/community' },
  ];

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans flex">
      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-[#141414] text-[#E4E3E0] transition-transform duration-300 ease-in-out transform border-r border-[#141414]",
          !isSidebarOpen && "-translate-x-full"
        )}
      >
        <div className="h-full flex flex-col">
          <div className="p-6 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-[#E4E3E0] rounded-sm flex items-center justify-center group-hover:rotate-45 transition-transform">
                <div className="w-4 h-4 bg-[#141414] rotate-45" />
              </div>
              <span className="font-mono font-bold tracking-tighter text-xl">ARCANA</span>
            </Link>
            <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden">
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 px-4 py-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-sm transition-all duration-200 group relative overflow-hidden",
                  location.pathname === item.path 
                    ? "bg-[#E4E3E0] text-[#141414]" 
                    : "hover:bg-[#E4E3E0]/10"
                )}
              >
                <item.icon size={18} className={cn(location.pathname === item.path ? "text-[#141414]" : "text-[#E4E3E0]/50")} />
                <span className="font-mono text-xs uppercase tracking-widest font-medium">{item.name}</span>
                {location.pathname === item.path && (
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-[#141414]" />
                )}
              </Link>
            ))}
          </nav>

          <div className="p-4 border-t border-[#E4E3E0]/10 space-y-4">
            {user ? (
              <div className="flex items-center gap-3 px-4 py-2">
                <img src={user.photoURL || 'https://picsum.photos/seed/user/100/100'} alt="User" className="w-8 h-8 rounded-full border border-[#E4E3E0]/20" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-mono truncate">{user.displayName}</p>
                  <p className="text-[10px] font-mono text-[#E4E3E0]/50 truncate">0x...{user.uid.slice(-4)}</p>
                </div>
                <button onClick={() => IdentityService.logout()} className="text-[#E4E3E0]/50 hover:text-white transition-colors">
                  <LogOut size={16} />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => IdentityService.login()}
                className="w-full flex items-center justify-center gap-2 bg-[#E4E3E0] text-[#141414] py-3 rounded-sm font-mono text-xs uppercase tracking-widest font-bold hover:bg-white transition-colors"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 transition-all duration-300 ease-in-out min-h-screen flex flex-col",
        isSidebarOpen ? "lg:ml-64" : "ml-0"
      )}>
        {/* Header */}
        <header className="h-16 bg-[#E4E3E0] border-b border-[#141414] flex items-center justify-between px-6 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            {!isSidebarOpen && (
              <button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-[#141414]/5 rounded-sm">
                <Menu size={20} />
              </button>
            )}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#141414]/40" size={16} />
              <input 
                type="text" 
                placeholder="SEARCH ASSETS, CREATORS, COLLECTIONS..." 
                className="bg-transparent border border-[#141414]/20 pl-10 pr-4 py-2 text-xs font-mono w-80 focus:outline-none focus:border-[#141414] transition-colors"
              />
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden lg:flex items-center gap-8 font-mono text-[10px] uppercase tracking-tighter">
              <div className="flex flex-col">
                <span className="text-[#141414]/40">ETH PRICE</span>
                <span>$2,450.12 <span className="text-green-600">+1.2%</span></span>
              </div>
              <div className="flex flex-col">
                <span className="text-[#141414]/40">GAS PRICE</span>
                <span>12 GWEI</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[#141414]/40">TOTAL VOLUME</span>
                <span>1.2M ETH</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-[#141414]/5 rounded-sm relative">
                <Bell size={20} />
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-[#E4E3E0]" />
              </button>
              <button className="p-2 hover:bg-[#141414]/5 rounded-sm">
                <Settings size={20} />
              </button>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 p-6 lg:p-10">
          {children}
        </div>

        {/* Footer */}
        <footer className="p-6 border-t border-[#141414] flex flex-col md:flex-row justify-between items-center gap-4 font-mono text-[10px] text-[#141414]/40">
          <p>© 2026 ARCANA DIGITAL PROTOCOL. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-6 uppercase tracking-widest">
            <a href="#" className="hover:text-[#141414]">Terms</a>
            <a href="#" className="hover:text-[#141414]">Privacy</a>
            <a href="#" className="hover:text-[#141414]">Docs</a>
            <a href="#" className="hover:text-[#141414]">Status</a>
          </div>
        </footer>
      </main>
    </div>
  );
}
