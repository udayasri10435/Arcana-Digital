import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Mic, Send, X, Sparkles, Volume2, Search, Loader2 } from 'lucide-react';
import { GeminiService, connectLiveAssistant } from '../lib/gemini';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  sources?: any[];
}

export const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isSearchMode, setIsSearchMode] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      if (isSearchMode) {
        const result = await GeminiService.searchMarketInfo(input);
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: result.text,
          sources: result.sources
        }]);
      } else {
        const response = await GeminiService.chat(input);
        setMessages(prev => [...prev, { role: 'assistant', content: response || "I'm sorry, I couldn't process that." }]);
      }
    } catch (error) {
      console.error('AI Error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Protocol error: AI service unavailable." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleVoice = () => {
    setIsVoiceActive(!isVoiceActive);
    // In a real implementation, we'd start/stop the Live API connection here
    if (!isVoiceActive) {
      setMessages(prev => [...prev, { role: 'assistant', content: "Voice mode active. (Simulated Live API connection)" }]);
    }
  };

  return (
    <>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 p-4 bg-orange-500 text-black rounded-full shadow-lg hover:scale-110 transition-transform z-50 flex items-center gap-2 font-mono font-bold"
      >
        <Sparkles size={20} />
        <span className="hidden md:inline">PROTOCOL ASSISTANT</span>
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-[400px] max-w-[90vw] h-[600px] bg-[#151619] border border-[#333] rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-[#333] bg-[#1a1b1e] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="font-mono text-xs font-bold tracking-widest text-white">ARCANA_AI_V1.0</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-white">
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-[#333]">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="p-4 bg-orange-500/10 rounded-full">
                    <Sparkles className="text-orange-500" size={32} />
                  </div>
                  <div>
                    <h3 className="font-mono text-white font-bold">ARCANA PROTOCOL ASSISTANT</h3>
                    <p className="text-xs text-gray-500 mt-2">Ask about marketplace trends, NFT minting, or protocol governance.</p>
                  </div>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-xl font-sans text-sm ${
                    msg.role === 'user'
                      ? 'bg-orange-500 text-black font-medium'
                      : 'bg-[#1a1b1e] text-gray-300 border border-[#333]'
                  }`}>
                    {msg.content}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-[#333] space-y-1">
                        <p className="text-[10px] uppercase font-bold text-gray-500">Sources:</p>
                        {msg.sources.map((s, si) => (
                          <a key={si} href={s.web?.uri} target="_blank" rel="noreferrer" className="block text-[10px] text-orange-500 hover:underline truncate">
                            {s.web?.title || s.web?.uri}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-[#1a1b1e] p-3 rounded-xl border border-[#333]">
                    <Loader2 className="animate-spin text-orange-500" size={16} />
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-[#1a1b1e] border-t border-[#333] space-y-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsSearchMode(!isSearchMode)}
                  className={`p-2 rounded-lg transition-colors ${isSearchMode ? 'bg-orange-500 text-black' : 'bg-[#222] text-gray-500 hover:text-white'}`}
                  title="Google Search Grounding"
                >
                  <Search size={16} />
                </button>
                <button
                  onClick={toggleVoice}
                  className={`p-2 rounded-lg transition-colors ${isVoiceActive ? 'bg-green-500 text-black' : 'bg-[#222] text-gray-500 hover:text-white'}`}
                  title="Live Voice Assistant"
                >
                  <Mic size={16} />
                </button>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder={isSearchMode ? "Search the web..." : "Type a message..."}
                    className="w-full bg-[#222] border border-[#333] rounded-lg py-2 px-3 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
                  />
                </div>
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="p-2 bg-orange-500 text-black rounded-lg hover:scale-105 transition-transform disabled:opacity-50"
                >
                  <Send size={16} />
                </button>
              </div>
              <div className="flex justify-between items-center px-1">
                <span className="text-[10px] font-mono text-gray-600 uppercase">
                  {isSearchMode ? "Grounding: Active" : "Mode: Standard"}
                </span>
                <span className="text-[10px] font-mono text-gray-600 uppercase">
                  v1.0.4-stable
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
