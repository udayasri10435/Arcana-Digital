import React, { useState, useEffect } from 'react';
import { Key, AlertCircle, ExternalLink, Sparkles, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface KeyGuardProps {
  children: React.ReactNode;
}

export const KeyGuard: React.FC<KeyGuardProps> = ({ children }) => {
  const [hasKey, setHasKey] = useState<boolean | null>(null);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } else {
        // Fallback for local dev or if the API is not available
        setHasKey(true);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      await window.aistudio.openSelectKey();
      // Assume success and proceed to the app as per instructions
      setHasKey(true);
    }
  };

  if (hasKey === null) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-6">
        <div className="w-12 h-12 border-4 border-orange-500/20 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!hasKey) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-6 font-sans">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-[#151619] border border-[#333] rounded-2xl p-8 shadow-2xl space-y-8"
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-4 bg-orange-500/10 rounded-full">
              <Key className="text-orange-500" size={48} />
            </div>
            <div className="space-y-2">
              <h1 className="text-2xl font-bold text-white tracking-tight">API KEY REQUIRED</h1>
              <p className="text-sm text-gray-500 leading-relaxed">
                To access Arcana Digital's high-performance AI features, including generative studio and live voice, you must select a valid Gemini API key.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <button
              onClick={handleSelectKey}
              className="w-full py-4 bg-orange-500 text-black font-bold rounded-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20"
            >
              <Sparkles size={20} />
              SELECT API KEY
            </button>

            <a
              href="https://ai.google.dev/gemini-api/docs/billing"
              target="_blank"
              rel="noreferrer"
              className="w-full py-4 bg-[#1a1b1e] text-gray-400 font-medium rounded-xl border border-[#333] hover:text-white hover:border-gray-500 transition-all flex items-center justify-center gap-2 text-sm"
            >
              <ExternalLink size={16} />
              VIEW BILLING DOCS
            </a>
          </div>

          <div className="pt-6 border-t border-[#333] flex items-center gap-3 text-[10px] text-gray-600 font-mono uppercase tracking-widest">
            <ShieldCheck size={14} className="text-green-500" />
            <span>Secure Protocol Verified</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return <>{children}</>;
};
