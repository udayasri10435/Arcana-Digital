import React, { useState, useEffect } from 'react';
import { Image as ImageIcon, Sparkles, Loader2, Download, Check, AlertCircle } from 'lucide-react';
import { GeminiService } from '../lib/gemini';
import { motion, AnimatePresence } from 'motion/react';

interface AIGeneratorProps {
  onImageGenerated: (imageUrl: string) => void;
}

export const AIGenerator: React.FC<AIGeneratorProps> = ({ onImageGenerated }) => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<"1K" | "2K" | "4K">("1K");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      }
    };
    checkKey();
  }, []);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    if (!hasKey) {
      if (window.aistudio?.openSelectKey) {
        await window.aistudio.openSelectKey();
        setHasKey(true);
      } else {
        setError("API Key selection is required for high-quality generation.");
        return;
      }
    }

    setIsGenerating(true);
    setError(null);
    try {
      const imageUrl = await GeminiService.generateImage(prompt, size);
      if (imageUrl) {
        setGeneratedImage(imageUrl);
        onImageGenerated(imageUrl);
      } else {
        setError("Failed to generate image. Please try a different prompt.");
      }
    } catch (err: any) {
      console.error('Generation Error:', err);
      if (err.message?.includes("Requested entity was not found")) {
        setHasKey(false);
        setError("API Key verification failed. Please re-select your key.");
      } else {
        setError("Protocol error: AI generation service unavailable.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-[#1a1b1e] border border-[#333] rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="text-orange-500" size={20} />
          <h3 className="font-mono text-white font-bold tracking-widest uppercase">AI GENERATIVE STUDIO</h3>
        </div>
        <div className="flex items-center gap-2">
          {(["1K", "2K", "4K"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSize(s)}
              className={`px-3 py-1 rounded-md font-mono text-[10px] border transition-colors ${
                size === s ? 'bg-orange-500 text-black border-orange-500' : 'bg-[#222] text-gray-500 border-[#333] hover:border-gray-500'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the digital asset you want to create..."
            className="w-full bg-[#222] border border-[#333] rounded-lg p-4 text-sm text-white focus:outline-none focus:border-orange-500 min-h-[100px] font-sans resize-none"
          />
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="absolute bottom-4 right-4 p-2 bg-orange-500 text-black rounded-lg hover:scale-105 transition-transform disabled:opacity-50 flex items-center gap-2 font-mono font-bold text-xs"
          >
            {isGenerating ? (
              <>
                <Loader2 className="animate-spin" size={14} />
                GENERATING...
              </>
            ) : (
              <>
                <Sparkles size={14} />
                GENERATE
              </>
            )}
          </button>
        </div>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-500 text-xs font-mono"
            >
              <AlertCircle size={14} />
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative aspect-square bg-[#222] border border-[#333] rounded-lg overflow-hidden flex items-center justify-center group">
          {generatedImage ? (
            <>
              <img src={generatedImage} alt="Generated Asset" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button
                  onClick={() => onImageGenerated(generatedImage)}
                  className="p-3 bg-orange-500 text-black rounded-full hover:scale-110 transition-transform"
                  title="Use this asset"
                >
                  <Check size={20} />
                </button>
                <a
                  href={generatedImage}
                  download="arcana-asset.png"
                  className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform"
                  title="Download"
                >
                  <Download size={20} />
                </a>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-2 text-gray-600">
              <ImageIcon size={48} strokeWidth={1} />
              <span className="font-mono text-[10px] uppercase tracking-widest">Awaiting Generation</span>
            </div>
          )}
          {isGenerating && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
              <div className="w-12 h-12 border-4 border-orange-500/20 border-t-orange-500 rounded-full animate-spin" />
              <p className="font-mono text-orange-500 text-[10px] animate-pulse uppercase tracking-[0.2em]">Synthesizing Digital Matter</p>
            </div>
          )}
        </div>
      </div>

      <div className="p-4 bg-orange-500/5 border border-orange-500/10 rounded-lg">
        <p className="text-[10px] text-orange-500/70 font-mono leading-relaxed">
          <span className="font-bold text-orange-500">PRO TIP:</span> Be specific about style, lighting, and composition. Try "Cyberpunk landscape, neon lighting, hyper-detailed, 8k, digital art style."
        </p>
      </div>
    </div>
  );
};
