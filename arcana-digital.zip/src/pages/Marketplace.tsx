import React from 'react';
import { motion } from 'motion/react';
import { 
  Filter, 
  ChevronDown, 
  ArrowUpRight, 
  Heart, 
  Share2, 
  ExternalLink,
  Zap,
  Shield,
  Clock,
  Flame,
  LayoutGrid
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { MarketplaceService, AnalyticsService } from '../lib/arcana';
import { Listing } from '../types';

export default function Marketplace() {
  const [listings, setListings] = React.useState<Listing[]>([]);
  const [stats, setStats] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const [activeListings, marketStats] = await Promise.all([
          MarketplaceService.getActiveListings(),
          AnalyticsService.getMarketStats()
        ]);
        setListings(activeListings);
        setStats(marketStats);
      } catch (error) {
        console.error('Error fetching marketplace data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-12 h-12 border-4 border-[#141414] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-[#141414] text-[#E4E3E0] p-12 rounded-sm border border-[#141414]">
        <div className="relative z-10 max-w-2xl space-y-6">
          <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-[0.2em] text-[#E4E3E0]/50">
            <Flame size={12} className="text-orange-500" />
            <span>Featured Collection: Genesis Arcana</span>
          </div>
          <h1 className="text-6xl font-mono font-bold tracking-tighter leading-none uppercase italic">
            DIGITAL SCARCITY <br /> REIMAGINED.
          </h1>
          <p className="text-sm font-mono text-[#E4E3E0]/70 leading-relaxed max-w-lg">
            The first institutional-grade marketplace for creator-owned digital assets, 
            NFTs, and token-gated experiences. Verifiable provenance. Instant fulfillment.
          </p>
          <div className="flex gap-4 pt-4">
            <button className="bg-[#E4E3E0] text-[#141414] px-8 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-white transition-colors flex items-center gap-2">
              Explore Drops <ArrowUpRight size={16} />
            </button>
            <button className="border border-[#E4E3E0]/20 px-8 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-[#E4E3E0]/10 transition-colors">
              Learn More
            </button>
          </div>
        </div>
        
        {/* Background Graphic */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-20 pointer-events-none overflow-hidden">
          <div className="absolute inset-0 grid grid-cols-10 gap-1">
            {Array.from({ length: 100 }).map((_, i) => (
              <div key={i} className="aspect-square bg-[#E4E3E0]/10 border border-[#E4E3E0]/5" />
            ))}
          </div>
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#141414]" />
        </div>
      </section>

      {/* Market Stats */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: '24H VOLUME', value: `${stats?.volume24h || 0} ETH`, change: '+12.5%' },
          { label: 'FLOOR PRICE', value: `${stats?.floorPrice || 0} ETH`, change: '+2.1%' },
          { label: 'TOTAL CREATORS', value: stats?.totalCreators || 0, change: '+45' },
          { label: 'ACTIVE LISTINGS', value: listings.length, change: '+12' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 border border-[#141414] rounded-sm space-y-2 group hover:bg-[#141414] hover:text-[#E4E3E0] transition-all duration-300">
            <p className="text-[10px] font-mono text-[#141414]/40 group-hover:text-[#E4E3E0]/40 uppercase tracking-widest">{stat.label}</p>
            <div className="flex items-end justify-between">
              <p className="text-2xl font-mono font-bold tracking-tighter">{stat.value}</p>
              <span className="text-[10px] font-mono text-green-600 group-hover:text-green-400">{stat.change}</span>
            </div>
          </div>
        ))}
      </section>

      {/* Filter Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-4 border-y border-[#141414]">
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 px-4 py-2 border border-[#141414] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors">
            <Filter size={14} /> Filters
          </button>
          <div className="flex gap-2">
            {['Art', 'Music', 'Gaming', 'Software', 'Collectibles'].map((cat) => (
              <button key={cat} className="px-4 py-2 bg-white border border-[#141414] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors">
                {cat}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[10px] font-mono text-[#141414]/40 uppercase tracking-widest">Sort By:</span>
          <button className="flex items-center gap-2 px-4 py-2 border border-[#141414] font-mono text-[10px] uppercase tracking-widest bg-white">
            Recently Listed <ChevronDown size={14} />
          </button>
        </div>
      </div>

      {/* Listings Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {listings.length > 0 ? (
          listings.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))
        ) : (
          <div className="col-span-full py-20 text-center space-y-4">
            <div className="w-16 h-16 bg-[#141414]/5 rounded-full flex items-center justify-center mx-auto">
              <LayoutGrid size={32} className="text-[#141414]/20" />
            </div>
            <p className="font-mono text-xs uppercase tracking-widest text-[#141414]/40">No active listings found in the protocol.</p>
          </div>
        )}
      </section>
    </div>
  );
}

function ListingCard({ listing }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="bg-white border border-[#141414] rounded-sm overflow-hidden group flex flex-col"
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-[#141414]/5">
        <img 
          src={`https://picsum.photos/seed/${listing.id}/600/600`} 
          alt="Asset" 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <div className="bg-[#141414] text-[#E4E3E0] px-2 py-1 text-[8px] font-mono uppercase tracking-widest flex items-center gap-1">
            <Shield size={10} className="text-blue-400" /> Verified
          </div>
          {listing.type === 'auction' && (
            <div className="bg-orange-500 text-white px-2 py-1 text-[8px] font-mono uppercase tracking-widest flex items-center gap-1">
              <Clock size={10} /> 12H LEFT
            </div>
          )}
        </div>
        <button className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-sm border border-[#141414]/10 rounded-full hover:bg-white transition-colors">
          <Heart size={14} className="text-[#141414]" />
        </button>
        
        {/* Hover Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-[#141414] to-transparent">
          <button className="w-full bg-[#E4E3E0] text-[#141414] py-3 font-mono text-[10px] uppercase tracking-widest font-bold hover:bg-white transition-colors flex items-center justify-center gap-2">
            <Zap size={14} fill="currentColor" /> Quick Buy
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4 flex-1 flex flex-col">
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-mono text-[#141414]/40 uppercase tracking-widest">Edition 1 of 10</p>
            <div className="flex gap-2">
              <Share2 size={12} className="text-[#141414]/40 hover:text-[#141414] cursor-pointer" />
              <ExternalLink size={12} className="text-[#141414]/40 hover:text-[#141414] cursor-pointer" />
            </div>
          </div>
          <h3 className="font-mono font-bold text-sm uppercase tracking-tight truncate">NEO-ARCANA #0{listing.id.slice(-3)}</h3>
        </div>

        <div className="flex items-center gap-2">
          <img src={`https://picsum.photos/seed/${listing.sellerId}/40/40`} className="w-5 h-5 rounded-full border border-[#141414]/10" />
          <span className="text-[10px] font-mono uppercase tracking-widest hover:underline cursor-pointer">Creator_Name</span>
        </div>

        <div className="pt-4 mt-auto border-t border-[#141414]/5 flex items-end justify-between">
          <div className="space-y-1">
            <p className="text-[8px] font-mono text-[#141414]/40 uppercase tracking-widest">Current Price</p>
            <p className="text-lg font-mono font-bold tracking-tighter">{formatCurrency(listing.price, listing.currency)}</p>
          </div>
          <div className="text-right space-y-1">
            <p className="text-[8px] font-mono text-[#141414]/40 uppercase tracking-widest">Last Sale</p>
            <p className="text-[10px] font-mono text-[#141414]/60">0.45 ETH</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
