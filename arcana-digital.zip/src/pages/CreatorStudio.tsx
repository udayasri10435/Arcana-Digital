import React from 'react';
import { motion } from 'motion/react';
import { 
  Upload, 
  Image as ImageIcon, 
  Music, 
  Video, 
  Box, 
  Plus, 
  Info,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Zap,
  Layers,
  Database,
  Shield
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AssetService, TokenService, IdentityService } from '../lib/arcana';
import { AIGenerator } from '../components/AIGenerator';

export default function CreatorStudio() {
  const [step, setStep] = React.useState(1);
  const [uploading, setUploading] = React.useState(false);
  const [formData, setFormData] = React.useState({
    title: '',
    description: '',
    royaltyBps: 500, // 5%
    blockchain: 'polygon' as any,
    assetType: 'image',
    fileURL: ''
  });

  const handleImageGenerated = (url: string) => {
    setFormData({ ...formData, fileURL: url });
  };

  const handleCreate = async () => {
    setUploading(true);
    try {
      // Use generated URL if available, otherwise fallback to mock
      const finalFileURL = formData.fileURL || 'https://picsum.photos/seed/asset/1920/1080';
      
      const assetId = await AssetService.uploadAsset({
        creatorId: 'mock-user-id',
        title: formData.title,
        description: formData.description,
        fileURL: finalFileURL,
        previewURL: finalFileURL,
        mimeType: 'image/jpeg',
      });

      // Simulate minting
      if (assetId) {
        await TokenService.mintToken({
          assetId,
          creatorId: 'mock-user-id',
          ownerId: 'mock-user-id',
          blockchain: formData.blockchain,
          royaltyBps: formData.royaltyBps,
        });
        setStep(3);
      }
    } catch (error) {
      console.error('Error in studio:', error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-[#141414] pb-8">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-[0.2em] text-[#141414]/50">
            <Layers size={12} />
            <span>Creator Operations Center</span>
          </div>
          <h1 className="text-5xl font-mono font-bold tracking-tighter uppercase italic">CREATOR STUDIO</h1>
          <p className="text-xs font-mono text-[#141414]/60 max-w-md">
            Deploy smart contracts, mint digital assets, and manage your creator economy from a single interface.
          </p>
        </div>
        <div className="flex gap-4">
          <div className="flex flex-col items-end">
            <span className="text-[8px] font-mono text-[#141414]/40 uppercase tracking-widest">Protocol Status</span>
            <div className="flex items-center gap-2 text-[10px] font-mono text-green-600">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span>MAINNET OPERATIONAL</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stepper */}
      <div className="flex items-center justify-between max-w-2xl mx-auto relative">
        <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-[#141414]/10 -translate-y-1/2 z-0" />
        {[
          { step: 1, label: 'ASSET UPLOAD' },
          { step: 2, label: 'MINTING CONFIG' },
          { step: 3, label: 'DEPLOYMENT' },
        ].map((s) => (
          <div key={s.step} className="relative z-10 flex flex-col items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-full border-2 flex items-center justify-center font-mono text-xs font-bold transition-all duration-300",
              step >= s.step ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" : "bg-white text-[#141414]/20 border-[#141414]/10"
            )}>
              {step > s.step ? <CheckCircle2 size={16} /> : s.step}
            </div>
            <span className={cn(
              "text-[8px] font-mono uppercase tracking-widest font-bold",
              step >= s.step ? "text-[#141414]" : "text-[#141414]/20"
            )}>{s.label}</span>
          </div>
        ))}
      </div>

      {/* Step Content */}
      <div className="bg-white border border-[#141414] rounded-sm overflow-hidden shadow-xl shadow-[#141414]/5">
        {step === 1 && (
          <div className="p-12 space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Asset Type</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'image', icon: ImageIcon, label: 'IMAGE' },
                      { id: 'video', icon: Video, label: 'VIDEO' },
                      { id: 'audio', icon: Music, label: 'AUDIO' },
                      { id: '3d', icon: Box, label: '3D MODEL' },
                    ].map((type) => (
                      <button
                        key={type.id}
                        onClick={() => setFormData({ ...formData, assetType: type.id })}
                        className={cn(
                          "flex items-center gap-3 p-4 border transition-all duration-200",
                          formData.assetType === type.id 
                            ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                            : "bg-white text-[#141414] border-[#141414]/10 hover:border-[#141414]"
                        )}
                      >
                        <type.icon size={16} />
                        <span className="font-mono text-[10px] uppercase tracking-widest">{type.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Title</label>
                  <input 
                    type="text" 
                    placeholder="ENTER ASSET TITLE..." 
                    className="w-full bg-transparent border border-[#141414]/20 p-4 font-mono text-xs focus:outline-none focus:border-[#141414] transition-colors"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Description</label>
                  <textarea 
                    rows={4}
                    placeholder="DESCRIBE YOUR CREATION..." 
                    className="w-full bg-transparent border border-[#141414]/20 p-4 font-mono text-xs focus:outline-none focus:border-[#141414] transition-colors resize-none"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
              </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">AI Co-Creator</label>
                  <AIGenerator onImageGenerated={handleImageGenerated} />
                </div>

                <div className="flex flex-col gap-6">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Manual File Upload</label>
                  <div className={cn(
                    "flex-1 border-2 border-dashed border-[#141414]/10 rounded-sm flex flex-col items-center justify-center p-12 text-center space-y-4 hover:border-[#141414]/30 transition-colors cursor-pointer group relative overflow-hidden",
                    formData.fileURL && "border-green-500/30 bg-green-50/10"
                  )}>
                    {formData.fileURL ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <img src={formData.fileURL} alt="Preview" className="w-full h-full object-cover opacity-20" />
                        <div className="relative z-10 flex flex-col items-center gap-2">
                          <CheckCircle2 className="text-green-500" size={32} />
                          <p className="font-mono text-[10px] uppercase font-bold text-green-600">Asset Ready for Minting</p>
                          <button 
                            onClick={(e) => { e.stopPropagation(); setFormData({ ...formData, fileURL: '' }); }}
                            className="text-[8px] font-mono uppercase text-red-500 hover:underline"
                          >
                            Clear Asset
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="w-16 h-16 bg-[#141414]/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                          <Upload size={24} className="text-[#141414]/40" />
                        </div>
                        <div className="space-y-1">
                          <p className="font-mono text-xs uppercase tracking-widest font-bold">Drag & Drop Files</p>
                          <p className="font-mono text-[10px] text-[#141414]/40">PNG, JPG, GIF, WEBP, MP4, MP3, GLB (MAX 100MB)</p>
                        </div>
                        <button className="bg-[#141414] text-[#E4E3E0] px-6 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-black transition-colors">
                          Browse Files
                        </button>
                      </>
                    )}
                  </div>
                <div className="p-4 bg-[#141414]/5 border border-[#141414]/10 flex gap-3">
                  <Info size={16} className="text-[#141414]/40 shrink-0" />
                  <p className="text-[10px] font-mono text-[#141414]/60 leading-relaxed uppercase tracking-tighter">
                    Assets are automatically pinned to IPFS for decentralized storage. Metadata follows the OpenSea metadata standard.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-8 border-t border-[#141414]/10">
              <button 
                onClick={() => setStep(2)}
                disabled={!formData.title}
                className="bg-[#141414] text-[#E4E3E0] px-10 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-black transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue to Minting <ArrowRight size={16} />
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="p-12 space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Select Blockchain</label>
                  <div className="space-y-2">
                    {[
                      { id: 'polygon', name: 'POLYGON', desc: 'LOW GAS, HIGH SPEED', icon: Zap },
                      { id: 'ethereum', name: 'ETHEREUM', desc: 'MAX SECURITY, L1', icon: Shield },
                      { id: 'base', name: 'BASE', desc: 'COINBASE L2 SCALING', icon: Box },
                    ].map((chain) => (
                      <button
                        key={chain.id}
                        onClick={() => setFormData({ ...formData, blockchain: chain.id as any })}
                        className={cn(
                          "w-full flex items-center justify-between p-4 border transition-all duration-200",
                          formData.blockchain === chain.id 
                            ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                            : "bg-white text-[#141414] border-[#141414]/10 hover:border-[#141414]"
                        )}
                      >
                        <div className="flex items-center gap-4">
                          <chain.icon size={18} />
                          <div className="text-left">
                            <p className="font-mono text-xs font-bold uppercase tracking-widest">{chain.name}</p>
                            <p className="font-mono text-[8px] opacity-60 uppercase tracking-widest">{chain.desc}</p>
                          </div>
                        </div>
                        {formData.blockchain === chain.id && <CheckCircle2 size={16} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/60">Creator Royalties</label>
                    <span className="text-xl font-mono font-bold">{formData.royaltyBps / 100}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="2000" 
                    step="50"
                    value={formData.royaltyBps}
                    onChange={(e) => setFormData({ ...formData, royaltyBps: parseInt(e.target.value) })}
                    className="w-full h-1 bg-[#141414]/10 rounded-lg appearance-none cursor-pointer accent-[#141414]"
                  />
                  <div className="flex justify-between text-[8px] font-mono text-[#141414]/40 uppercase tracking-widest">
                    <span>0%</span>
                    <span>10%</span>
                    <span>20% (MAX)</span>
                  </div>
                  <p className="text-[10px] font-mono text-[#141414]/60 italic">
                    Royalties are enforced at the protocol level via ERC-2981.
                  </p>
                </div>
              </div>

              <div className="bg-[#141414]/5 p-8 border border-[#141414]/10 space-y-6">
                <h3 className="font-mono text-xs font-bold uppercase tracking-widest border-b border-[#141414]/10 pb-4">Minting Summary</h3>
                <div className="space-y-4">
                  <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                    <span className="text-[#141414]/40">Asset</span>
                    <span>{formData.title}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                    <span className="text-[#141414]/40">Network</span>
                    <span className="font-bold">{formData.blockchain}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                    <span className="text-[#141414]/40">Royalties</span>
                    <span>{formData.royaltyBps / 100}%</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                    <span className="text-[#141414]/40">Estimated Gas</span>
                    <span className="text-green-600">~$0.45 USD</span>
                  </div>
                </div>
                <div className="pt-6 border-t border-[#141414]/10 space-y-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle size={14} className="text-orange-500 shrink-0" />
                    <p className="text-[8px] font-mono text-[#141414]/60 uppercase tracking-tighter leading-relaxed">
                      Minting is a permanent on-chain action. Ensure all metadata is correct before proceeding.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-8 border-t border-[#141414]/10">
              <button 
                onClick={() => setStep(1)}
                className="px-10 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-[#141414]/5 transition-colors"
              >
                Back
              </button>
              <button 
                onClick={handleCreate}
                disabled={uploading}
                className="bg-[#141414] text-[#E4E3E0] px-10 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-black transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                {uploading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#E4E3E0] border-t-transparent rounded-full animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Confirm & Mint <Zap size={16} fill="currentColor" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="p-20 text-center space-y-8">
            <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 size={48} />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-mono font-bold tracking-tighter uppercase italic">MINTING SUCCESSFUL</h2>
              <p className="text-xs font-mono text-[#141414]/60 uppercase tracking-widest">
                Your asset has been deployed to the {formData.blockchain} network.
              </p>
            </div>
            <div className="max-w-md mx-auto p-6 bg-[#141414]/5 border border-[#141414]/10 space-y-4">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                <span className="text-[#141414]/40">Transaction Hash</span>
                <span className="text-blue-600 hover:underline cursor-pointer">0x7a2...f89e</span>
              </div>
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                <span className="text-[#141414]/40">Token ID</span>
                <span>#4029</span>
              </div>
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                <span className="text-[#141414]/40">IPFS CID</span>
                <span className="text-blue-600 hover:underline cursor-pointer">QmXoyp...</span>
              </div>
            </div>
            <div className="flex justify-center gap-4 pt-4">
              <button 
                onClick={() => setStep(1)}
                className="border border-[#141414] px-8 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-[#141414]/5 transition-colors"
              >
                Mint Another
              </button>
              <button className="bg-[#141414] text-[#E4E3E0] px-8 py-4 font-mono text-xs uppercase tracking-widest font-bold hover:bg-black transition-colors">
                View in Marketplace
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#141414] pb-4">
          <h2 className="font-mono text-xs font-bold uppercase tracking-widest flex items-center gap-2">
            <Database size={14} /> Recent Deployments
          </h2>
          <button className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/40 hover:text-[#141414]">View All History</button>
        </div>
        <div className="bg-white border border-[#141414] rounded-sm overflow-hidden">
          <table className="w-full text-left font-mono text-[10px] uppercase tracking-widest">
            <thead className="bg-[#141414]/5 border-b border-[#141414]">
              <tr>
                <th className="px-6 py-4 font-bold">Asset</th>
                <th className="px-6 py-4 font-bold">Network</th>
                <th className="px-6 py-4 font-bold">Status</th>
                <th className="px-6 py-4 font-bold">Royalties</th>
                <th className="px-6 py-4 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141414]/5">
              {[
                { name: 'CYBER_PUNK_01', chain: 'Polygon', status: 'Minted', royalty: '5%' },
                { name: 'NEO_TOKYO_NIGHTS', chain: 'Ethereum', status: 'Pending', royalty: '10%' },
                { name: 'VOID_WALKER_3D', chain: 'Base', status: 'Minted', royalty: '7.5%' },
              ].map((item, i) => (
                <tr key={i} className="hover:bg-[#141414]/5 transition-colors">
                  <td className="px-6 py-4 font-bold">{item.name}</td>
                  <td className="px-6 py-4">{item.chain}</td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded-full text-[8px]",
                      item.status === 'Minted' ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"
                    )}>{item.status}</span>
                  </td>
                  <td className="px-6 py-4">{item.royalty}</td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-blue-600 hover:underline">List for Sale</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
